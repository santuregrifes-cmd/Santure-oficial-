"use client"

import { Minus, Plus, ShoppingBag, Trash2, MapPin, Calculator } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Header from "@/components/header"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"
import { useCart } from "@/contexts/cart-context"
import Link from "next/link"
import { useState } from "react"

export default function CarrinhoPage() {
  const { state, updateQuantity, removeItem, clearCart, getTotalPrice, getTotalItems } = useCart()

  const [shippingData, setShippingData] = useState({
    cep: "",
    endereco: "",
    numero: "",
    bairro: "",
    cidade: "",
    complemento: "",
  })
  const [shippingCost, setShippingCost] = useState(0)
  const [isShippingCalculated, setIsShippingCalculated] = useState(false)
  const [shippingError, setShippingError] = useState("")

  const calculateShipping = () => {
    setShippingError("")

    if (!shippingData.cep || !shippingData.cidade) {
      setShippingError("Por favor, preencha CEP e cidade")
      return
    }

    // Verificar se é Goiás
    const goiasCities = [
      "gravelo",
      "goiânia",
      "goiania",
      "aparecida de goiânia",
      "aparecida de goiania",
      "senador canedo",
      "trindade",
      "anápolis",
      "anapolis",
    ]
    const cityLower = shippingData.cidade.toLowerCase()

    // Verificar se a cidade está em Goiás
    const isGoias = goiasCities.some((city) => cityLower.includes(city)) || cityLower.includes("go")

    if (!isGoias) {
      setShippingError("Desculpe, entregamos apenas no estado de Goiás")
      setShippingCost(0)
      setIsShippingCalculated(false)
      return
    }

    // Frete grátis para Gravelo e região
    if (cityLower.includes("gravelo")) {
      setShippingCost(0)
    } else if (
      cityLower.includes("goiânia") ||
      cityLower.includes("goiania") ||
      cityLower.includes("aparecida") ||
      cityLower.includes("senador canedo") ||
      cityLower.includes("trindade")
    ) {
      setShippingCost(15.9) // Região metropolitana
    } else {
      setShippingCost(25.9) // Interior de Goiás
    }

    setIsShippingCalculated(true)
  }

  const handleCheckout = () => {
    if (state.items.length === 0) return

    if (!isShippingCalculated) {
      setShippingError("Por favor, calcule o frete antes de finalizar a compra")
      return
    }

    const itemsList = state.items
      .map((item) => `${item.name} (${item.size}) - Qtd: ${item.quantity} - ${item.price}`)
      .join("\n")

    const subtotal = getTotalPrice()
    const total = subtotal + shippingCost

    const message = `Olá! Gostaria de finalizar minha compra:

*PRODUTOS:*
${itemsList}

*ENDEREÇO DE ENTREGA:*
${shippingData.endereco}, ${shippingData.numero}
${shippingData.bairro} - ${shippingData.cidade}
CEP: ${shippingData.cep}
${shippingData.complemento ? `Complemento: ${shippingData.complemento}` : ""}

*RESUMO:*
Subtotal: ${subtotal.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
Frete: ${shippingCost === 0 ? "GRÁTIS" : shippingCost.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
*Total: ${total.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}*`

    const whatsappUrl = `https://wa.me/5562995432028?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      <div className="pt-20 pb-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="font-serif font-bold text-3xl text-slate-700 mb-2">Carrinho de Compras</h1>
            <p className="text-slate-600">
              {getTotalItems()} {getTotalItems() === 1 ? "item" : "itens"} no seu carrinho
            </p>
          </div>

          {state.items.length === 0 ? (
            /* Empty Cart */
            <Card className="p-12 text-center">
              <ShoppingBag className="h-24 w-24 text-slate-300 mx-auto mb-6" />
              <h2 className="font-serif font-semibold text-2xl text-slate-600 mb-4">Seu carrinho está vazio</h2>
              <p className="text-slate-500 mb-8">Que tal dar uma olhada em nossos produtos incríveis?</p>
              <Link href="/catalogo">
                <Button size="lg" className="bg-amber-600 hover:bg-amber-700">
                  Explorar Produtos
                </Button>
              </Link>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2 space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="font-semibold text-lg">Itens do Carrinho</h2>
                  <Button variant="ghost" onClick={clearCart} className="text-red-500 hover:text-red-700">
                    <Trash2 className="h-4 w-4 mr-2" />
                    Limpar Carrinho
                  </Button>
                </div>

                {state.items.map((item) => (
                  <Card key={`${item.id}-${item.size}`} className="p-6">
                    <div className="flex gap-6">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="w-24 h-24 object-cover rounded-lg"
                      />

                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-serif font-semibold text-lg">{item.name}</h3>
                            <p className="text-slate-500">{item.brand}</p>
                            <p className="text-sm text-slate-500">Tamanho: {item.size}</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeItem(item.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              disabled={item.quantity <= 1}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span className="text-lg font-medium w-12 text-center">{item.quantity}</span>
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>

                          <div className="text-right">
                            <p className="text-2xl font-bold text-amber-600">{item.price}</p>
                            <p className="text-sm text-slate-500">por unidade</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}

                <Card className="p-6 mt-6">
                  <div className="flex items-center gap-2 mb-4">
                    <MapPin className="h-5 w-5 text-amber-600" />
                    <h3 className="font-serif font-semibold text-lg">Endereço de Entrega</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="cep">CEP *</Label>
                      <Input
                        id="cep"
                        placeholder="00000-000"
                        value={shippingData.cep}
                        onChange={(e) => setShippingData({ ...shippingData, cep: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="cidade">Cidade *</Label>
                      <Input
                        id="cidade"
                        placeholder="Ex: Gravelo, Goiânia..."
                        value={shippingData.cidade}
                        onChange={(e) => setShippingData({ ...shippingData, cidade: e.target.value })}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Label htmlFor="endereco">Endereço *</Label>
                      <Input
                        id="endereco"
                        placeholder="Rua, Avenida..."
                        value={shippingData.endereco}
                        onChange={(e) => setShippingData({ ...shippingData, endereco: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="numero">Número *</Label>
                      <Input
                        id="numero"
                        placeholder="123"
                        value={shippingData.numero}
                        onChange={(e) => setShippingData({ ...shippingData, numero: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="bairro">Bairro</Label>
                      <Input
                        id="bairro"
                        placeholder="Nome do bairro"
                        value={shippingData.bairro}
                        onChange={(e) => setShippingData({ ...shippingData, bairro: e.target.value })}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Label htmlFor="complemento">Complemento</Label>
                      <Input
                        id="complemento"
                        placeholder="Apartamento, bloco, referência..."
                        value={shippingData.complemento}
                        onChange={(e) => setShippingData({ ...shippingData, complemento: e.target.value })}
                      />
                    </div>
                  </div>

                  <Button onClick={calculateShipping} className="mt-4 bg-amber-600 hover:bg-amber-700">
                    <Calculator className="h-4 w-4 mr-2" />
                    Calcular Frete
                  </Button>

                  {shippingError && (
                    <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-red-600 text-sm">{shippingError}</p>
                    </div>
                  )}

                  {isShippingCalculated && !shippingError && (
                    <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                      <p className="text-green-700 font-medium">
                        Frete calculado:{" "}
                        {shippingCost === 0
                          ? "GRÁTIS"
                          : shippingCost.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                      </p>
                      <p className="text-green-600 text-sm mt-1">
                        {shippingCost === 0 ? "Parabéns! Você tem frete grátis!" : "Entrega em até 3 dias úteis"}
                      </p>
                    </div>
                  )}
                </Card>
              </div>

              {/* Order Summary */}
              <div className="lg:col-span-1">
                <Card className="p-6 sticky top-24">
                  <h2 className="font-serif font-semibold text-xl mb-6">Resumo do Pedido</h2>

                  <div className="space-y-4 mb-6">
                    <div className="flex justify-between">
                      <span>Subtotal ({getTotalItems()} itens)</span>
                      <span>
                        {getTotalPrice().toLocaleString("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                        })}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Frete</span>
                      <span className={shippingCost === 0 ? "text-green-600" : ""}>
                        {isShippingCalculated
                          ? shippingCost === 0
                            ? "GRÁTIS"
                            : shippingCost.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
                          : "Calcular"}
                      </span>
                    </div>
                    <hr />
                    <div className="flex justify-between text-xl font-bold">
                      <span>Total</span>
                      <span className="text-amber-600">
                        {(getTotalPrice() + shippingCost).toLocaleString("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                        })}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Button
                      onClick={handleCheckout}
                      size="lg"
                      className="w-full bg-amber-600 hover:bg-amber-700"
                      disabled={!isShippingCalculated}
                    >
                      Finalizar Compra
                    </Button>
                    <Link href="/catalogo">
                      <Button variant="outline" size="lg" className="w-full bg-transparent">
                        Continuar Comprando
                      </Button>
                    </Link>
                  </div>

                  {/* Trust Indicators */}
                  <div className="mt-6 pt-6 border-t space-y-2 text-sm text-slate-600">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>Frete grátis para Gravelo e região</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span>Entregas apenas em Goiás</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                      <span>Pagamento seguro</span>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          )}
        </div>
      </div>

      <WhatsAppButton />
      <Footer />
    </main>
  )
}
