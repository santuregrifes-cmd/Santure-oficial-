"use client"

import { useState } from "react"
import Header from "@/components/header"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"
import ProductCard from "@/components/product-card"
import ProductFilters from "@/components/product-filters"
import { Button } from "@/components/ui/button"

const allProducts = [
  // Camisas
  {
    id: 1,
    name: "Camiseta Gucci Classic White",
    brand: "Gucci",
    price: "R$ 79,99",
    image: "/gucci-white-classic-logo.png",
    category: "camisa",
    description: "Camiseta branca premium com logo GUCCI dourado e faixa icônica",
  },
  {
    id: 2,
    name: "Camiseta Louis Vuitton Monogram Black",
    brand: "Louis Vuitton",
    price: "R$ 79,99",
    image: "/louis-vuitton-monogram-black.png",
    category: "camisa",
    description: "Camiseta preta premium com padrão monogram LV prateado degradê",
  },
  {
    id: 3,
    name: "Camiseta Hugo Boss Logo Gold",
    brand: "Hugo Boss",
    price: "R$ 79,99",
    image: "/hugo-boss-black-gold-logo.png",
    category: "camisa",
    description: "Camiseta preta premium com logo BOSS dourado em destaque",
  },
  {
    id: 4,
    name: "Camiseta Armani Eagle Black",
    brand: "Armani",
    price: "R$ 79,99",
    image: "/armani-eagle-black.png",
    category: "camisa",
    description: "Camiseta preta premium com logo da águia GA branco",
  },
  {
    id: 5,
    name: "Camiseta Balmain Paris Black",
    brand: "Balmain",
    price: "R$ 79,99",
    image: "/balmain-paris-black-gold.png",
    category: "camisa",
    description: "Camiseta preta premium com logo BALMAIN PARIS dourado em destaque",
  },
  {
    id: 15,
    name: "Camiseta Hugo Boss Logo White",
    brand: "Hugo Boss",
    price: "R$ 79,99",
    image: "/hugo-boss-black-white-logo.png",
    category: "camisa",
    description: "Camiseta preta premium com logo BOSS branco clássico",
  },
  {
    id: 16,
    name: "Camiseta Hugo Boss Logo Silver",
    brand: "Hugo Boss",
    price: "R$ 79,99",
    image: "/hugo-boss-black-silver-logo.png",
    category: "camisa",
    description: "Camiseta preta premium com logo BOSS prateado moderno",
  },
  {
    id: 17,
    name: "Camiseta Gucci Classic Black",
    brand: "Gucci",
    price: "R$ 79,99",
    image: "/gucci-black-classic-logo.png",
    category: "camisa",
    description: "Camiseta preta premium com logo GUCCI dourado e faixa icônica",
  },
  {
    id: 18,
    name: "Camiseta Hugo Boss White Gold",
    brand: "Hugo Boss",
    price: "R$ 79,99",
    image: "/hugo-boss-white-gold-logo.png",
    category: "camisa",
    description: "Camiseta branca premium com logo BOSS dourado elegante",
  },
  {
    id: 19,
    name: "Camiseta Hugo Boss Red Gold",
    brand: "Hugo Boss",
    price: "R$ 79,99",
    image: "/hugo-boss-red-gold-logo.png",
    category: "camisa",
    description: "Camiseta vermelha premium com logo BOSS dourado vibrante",
  },
  {
    id: 20,
    name: "Camiseta Armani Eagle White",
    brand: "Armani",
    price: "R$ 79,99",
    image: "/armani-eagle-white.png",
    category: "camisa",
    description: "Camiseta branca premium com logo da águia GA preto",
  },
  {
    id: 21,
    name: "Camiseta Armani Eagle Navy",
    brand: "Armani",
    price: "R$ 79,99",
    image: "/armani-eagle-navy.png",
    category: "camisa",
    description: "Camiseta azul marinho premium com logo da águia GA branco",
  },
  {
    id: 22,
    name: "Camiseta Armani Eagle Red",
    brand: "Armani",
    price: "R$ 79,99",
    image: "/armani-eagle-red.png",
    category: "camisa",
    description: "Camiseta vermelha premium com logo da águia GA branco",
  },
  {
    id: 23,
    name: "Camiseta Balmain Paris White",
    brand: "Balmain",
    price: "R$ 79,99",
    image: "/balmain-paris-white-black.png",
    category: "camisa",
    description: "Camiseta branca premium com logo BALMAIN PARIS preto elegante",
  },
  {
    id: 24,
    name: "Camiseta Louis Vuitton Monogram White",
    brand: "Louis Vuitton",
    price: "R$ 79,99",
    image: "/louis-vuitton-monogram-white.png",
    category: "camisa",
    description: "Camiseta branca premium com padrão monogram LV dourado elegante",
  },

  // Bermudas Hugo Boss
  {
    id: 6,
    name: "Bermuda Hugo Boss White",
    brand: "Hugo Boss",
    price: "R$ 65,99",
    image: "/hugo-boss-shorts-white.png",
    category: "bermuda",
    description: "Bermuda branca premium com logo BOSS vertical lateral",
  },
  {
    id: 25,
    name: "Bermuda Hugo Boss Black",
    brand: "Hugo Boss",
    price: "R$ 65,99",
    image: "/hugo-boss-shorts-black.png",
    category: "bermuda",
    description: "Bermuda preta premium com logo BOSS vertical lateral",
  },
  {
    id: 27,
    name: "Bermuda Hugo Boss Gray",
    brand: "Hugo Boss",
    price: "R$ 65,99",
    image: "/hugo-boss-shorts-gray.png",
    category: "bermuda",
    description: "Bermuda cinza premium com logo BOSS vertical lateral",
  },

  // Bermudas Gucci
  {
    id: 7,
    name: "Bermuda Gucci GG Black",
    brand: "Gucci",
    price: "R$ 65,99",
    image: "/gucci-gg-shorts-black.png",
    category: "bermuda",
    description: "Bermuda preta premium com faixas laterais GG bege icônicas",
  },
  {
    id: 28,
    name: "Bermuda Gucci GG Navy",
    brand: "Gucci",
    price: "R$ 65,99",
    image: "/gucci-gg-shorts-navy.png",
    category: "bermuda",
    description: "Bermuda azul marinho premium com faixas laterais GG douradas",
  },
  {
    id: 29,
    name: "Bermuda Gucci GG White",
    brand: "Gucci",
    price: "R$ 65,99",
    image: "/gucci-gg-shorts-white.png",
    category: "bermuda",
    description: "Bermuda branca premium com faixas laterais GG pretas elegantes",
  },
  {
    id: 36,
    name: "Bermuda Gucci GG Gray",
    brand: "Gucci",
    price: "R$ 65,99",
    image: "/gucci-gg-shorts-gray.png",
    category: "bermuda",
    description: "Bermuda cinza premium com faixas laterais GG verdes clássicas",
  },
  {
    id: 37,
    name: "Bermuda Gucci GG Beige",
    brand: "Gucci",
    price: "R$ 65,99",
    image: "/gucci-gg-shorts-beige.png",
    category: "bermuda",
    description: "Bermuda bege premium com faixas laterais GG marrom sofisticadas",
  },

  // Bermudas Louis Vuitton
  {
    id: 8,
    name: "Bermuda Louis Vuitton Monogram Black",
    brand: "Louis Vuitton",
    price: "R$ 65,99",
    image: "/lv-monogram-shorts-black.png",
    category: "bermuda",
    description: "Bermuda preta premium com padrão monogram LV all-over tonal elegante",
  },
  {
    id: 30,
    name: "Bermuda Louis Vuitton Monogram Navy",
    brand: "Louis Vuitton",
    price: "R$ 65,99",
    image: "/lv-monogram-shorts-navy.png",
    category: "bermuda",
    description: "Bermuda azul marinho premium com padrão monogram LV all-over dourado",
  },
  {
    id: 31,
    name: "Bermuda Louis Vuitton Monogram White",
    brand: "Louis Vuitton",
    price: "R$ 65,99",
    image: "/lv-monogram-shorts-white.png",
    category: "bermuda",
    description: "Bermuda branca premium com padrão monogram LV all-over preto sofisticado",
  },
  {
    id: 40,
    name: "Bermuda Louis Vuitton Monogram Brown",
    brand: "Louis Vuitton",
    price: "R$ 65,99",
    image: "/lv-monogram-shorts-brown.png",
    category: "bermuda",
    description: "Bermuda marrom premium com padrão monogram LV all-over dourado clássico",
  },
  {
    id: 41,
    name: "Bermuda Louis Vuitton Monogram Gray",
    brand: "Louis Vuitton",
    price: "R$ 65,99",
    image: "/lv-monogram-shorts-gray.png",
    category: "bermuda",
    description: "Bermuda cinza premium com padrão monogram LV all-over prateado moderno",
  },

  // Bermudas Armani
  {
    id: 9,
    name: "Bermuda Armani White",
    brand: "Armani",
    price: "R$ 65,99",
    image: "/emporio-armani-shorts-white.png",
    category: "bermuda",
    description: "Bermuda branca premium com logos EMPORIO ARMANI grandes em preto",
  },
  {
    id: 32,
    name: "Bermuda Armani Black",
    brand: "Armani",
    price: "R$ 65,99",
    image: "/emporio-armani-shorts-black.png",
    category: "bermuda",
    description: "Bermuda preta premium com logos EMPORIO ARMANI grandes em branco",
  },
  {
    id: 33,
    name: "Bermuda Armani Navy",
    brand: "Armani",
    price: "R$ 65,99",
    image: "/emporio-armani-shorts-navy.png",
    category: "bermuda",
    description: "Bermuda azul marinho premium com logos EMPORIO ARMANI grandes em branco",
  },
  {
    id: 38,
    name: "Bermuda Armani Gray",
    brand: "Armani",
    price: "R$ 65,99",
    image: "/emporio-armani-shorts-gray.png",
    category: "bermuda",
    description: "Bermuda cinza premium com logos EMPORIO ARMANI grandes em preto",
  },
  {
    id: 39,
    name: "Bermuda Armani Red",
    brand: "Armani",
    price: "R$ 65,99",
    image: "/emporio-armani-shorts-red.png",
    category: "bermuda",
    description: "Bermuda vermelha premium com logos EMPORIO ARMANI grandes em branco",
  },

  // Bermudas Balmain
  {
    id: 35,
    name: "Bermuda Balmain Red",
    brand: "Balmain",
    price: "R$ 65,99",
    image: "/balmain-vertical-shorts-red.png",
    category: "bermuda",
    description: "Bermuda vermelha premium com logo BALMAIN vertical lateral branco",
    outOfStock: true,
  },

  // Malhas Peruanas
  {
    id: 13,
    name: "Camiseta Hugo Boss Malha Peruana",
    brand: "Hugo Boss",
    price: "R$ 79,99",
    image: "/hugo-boss-peruvian-cotton.png",
    category: "camisa",
    description: "Camiseta Hugo Boss em algodão peruano premium com logo BOSS dourado",
  },
]

export default function CatalogoPage() {
  const [filteredProducts, setFilteredProducts] = useState(allProducts)
  const [selectedBrand, setSelectedBrand] = useState("all")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("name")

  const handleFilterChange = (brand: string, category: string, sort: string) => {
    let filtered = [...allProducts]

    // Filter by brand
    if (brand !== "all") {
      filtered = filtered.filter((product) => product.brand === brand)
    }

    // Filter by category
    if (category !== "all") {
      filtered = filtered.filter((product) => product.category === category)
    }

    // Sort products
    filtered.sort((a, b) => {
      switch (sort) {
        case "price-low":
          return (
            Number.parseFloat(a.price.replace("R$ ", "").replace(",", ".")) -
            Number.parseFloat(b.price.replace("R$ ", "").replace(",", "."))
          )
        case "price-high":
          return (
            Number.parseFloat(b.price.replace("R$ ", "").replace(",", ".")) -
            Number.parseFloat(a.price.replace("R$ ", "").replace(",", "."))
          )
        case "brand":
          return a.brand.localeCompare(b.brand)
        default:
          return a.name.localeCompare(b.name)
      }
    })

    setFilteredProducts(filtered)
    setSelectedBrand(brand)
    setSelectedCategory(category)
    setSortBy(sort)
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <Header />

      <div className="pt-20 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="text-center mb-12">
            <h1 className="font-serif font-bold text-4xl text-slate-700 mb-4">Catálogo Completo</h1>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Explore nossa coleção completa de roupas de grife com preços exclusivos
            </p>
          </div>

          <div className="flex flex-col lg:flex-row gap-8">
            {/* Filters Sidebar */}
            <div className="lg:w-1/4">
              <ProductFilters
                selectedBrand={selectedBrand}
                selectedCategory={selectedCategory}
                sortBy={sortBy}
                onFilterChange={handleFilterChange}
              />
            </div>

            {/* Products Grid */}
            <div className="lg:w-3/4">
              <div className="mb-6 flex justify-between items-center">
                <p className="text-slate-600">
                  Mostrando {filteredProducts.length} produto{filteredProducts.length !== 1 ? "s" : ""}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>

              {filteredProducts.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-slate-500 text-lg">Nenhum produto encontrado com os filtros selecionados.</p>
                  <Button
                    onClick={() => handleFilterChange("all", "all", "name")}
                    className="mt-4 bg-amber-600 hover:bg-amber-700"
                  >
                    Limpar Filtros
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <WhatsAppButton />
      <Footer />
    </main>
  )
}
