import Header from "@/components/header"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"
import ContactForm from "@/components/contact-form"
import ContactInfo from "@/components/contact-info"

export const metadata = {
  title: "Contato - Grife Store",
  description: "Entre em contato conosco. WhatsApp: (62) 9 9543-2028. Atendimento especializado em roupas de grife.",
}

export default function ContatoPage() {
  return (
    <main className="min-h-screen bg-white">
      <Header />

      <div className="pt-20">
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-slate-50 to-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="font-serif font-bold text-4xl sm:text-5xl text-slate-700 mb-6">Entre em Contato</h1>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed">
              Estamos aqui para ajudar você a encontrar as melhores peças de grife. Fale conosco!
            </p>
          </div>
        </section>

        {/* Contact Content */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <ContactInfo />
              <ContactForm />
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="font-serif font-bold text-3xl text-slate-700 mb-4">Perguntas Frequentes</h2>
              <p className="text-lg text-slate-600">Respostas para as dúvidas mais comuns</p>
            </div>

            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="font-semibold text-lg text-slate-700 mb-3">
                  Como posso ter certeza da autenticidade das peças?
                </h3>
                <p className="text-slate-600">
                  Todas as nossas peças são 100% autênticas. Oferecemos garantia de autenticidade ou seu dinheiro de
                  volta. Cada produto vem com certificado de originalidade.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="font-semibold text-lg text-slate-700 mb-3">Qual o prazo de entrega?</h3>
                <p className="text-slate-600">
                  Entregamos para todo o Brasil. Frete grátis para Goiânia e região. O prazo varia de 3 a 7 dias úteis
                  dependendo da sua localização. Você receberá o código de rastreamento por WhatsApp.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="font-semibold text-lg text-slate-700 mb-3">Posso trocar se não servir?</h3>
                <p className="text-slate-600">
                  Sim! Você tem até 30 dias para trocar qualquer peça. Você pode solicitar pelo WhatsApp. Enviamos uma
                  nova peça e coletamos a anterior.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="font-semibold text-lg text-slate-700 mb-3">Como funciona o pagamento?</h3>
                <p className="text-slate-600">
                  Aceitamos PIX, cartão de crédito e débito. O pagamento é processado de forma segura. Para compras via
                  WhatsApp, enviamos o link de pagamento após a confirmação do pedido.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="font-semibold text-lg text-slate-700 mb-3">Vocês têm loja física?</h3>
                <p className="text-slate-600">
                  Somos uma loja online especializada em roupas de grife com preços acessíveis. Todo atendimento é feito
                  via WhatsApp para oferecer o melhor preço e conveniência.
                </p>
              </div>
            </div>
          </div>
        </section>
      </div>

      <WhatsAppButton />
      <Footer />
    </main>
  )
}
