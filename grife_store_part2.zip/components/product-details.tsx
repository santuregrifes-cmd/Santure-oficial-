"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Minus, Plus, Heart, Share2, Truck, Shield, MapPin } from "lucide-react"
import { useCart } from "@/contexts/cart-context"

interface Product {
  id: number
  name: string
  brand: string
  price: string
  originalPrice: string
  images: string[]
  category: string
  description: string
  features: string[]
  sizes: string[]
  inStock: boolean
  sku: string
}

interface ProductDetailsProps {
  product: Product
}

export default function ProductDetails({ product }: ProductDetailsProps) {
  const [selectedImage, setSelectedImage] = useState(0)
  const [selectedSize, setSelectedSize] = useState("")
  const [selectedColor, setSelectedColor] = useState("")
  const [quantity, setQuantity] = useState(1)
  const [showAddressModal, setShowAddressModal] = useState(false)
  const [addressData, setAddressData] = useState({
    cep: "",
    endereco: "",
    numero: "",
    bairro: "",
    cidade: "",
    estado: "",
  })
  const [shippingCost, setShippingCost] = useState(0)
  const [isValidAddress, setIsValidAddress] = useState(false)

  const { addItem, openCart } = useCart()

  const availableColors = [
    { name: "Branco", value: "branco", color: "#FFFFFF", border: "#E5E7EB" },
    { name: "Vermelho", value: "vermelho", color: "#DC2626", border: "#DC2626" },
    { name: "Preto", value: "preto", color: "#000000", border: "#000000" },
  ]

  const showColorSelector = product.category === "bermudas" || product.category === "camisas"

  const calculateShipping = (cidade: string, estado: string) => {
    if (estado.toLowerCase() !== "goiás" && estado.toLowerCase() !== "goias" && estado.toLowerCase() !== "go") {
      return -1 // Não entrega fora de Goiás
    }

    const cidadeLower = cidade.toLowerCase()
    if (cidadeLower.includes("gravelo") || cidadeLower.includes("gravatá")) {
      return 0 // Frete grátis para Gravelo e região
    }

    // Região metropolitana de Goiânia
    const metropolitana = [
      "goiânia",
      "goiania",
      "aparecida de goiânia",
      "aparecida",
      "senador canedo",
      "trindade",
      "abadia de goiás",
      "abadia",
    ]
    if (metropolitana.some((city) => cidadeLower.includes(city))) {
      return 15.9
    }

    // Interior de Goiás
    return 25.9
  }

  const handleCepChange = async (cep: string) => {
    setAddressData((prev) => ({ ...prev, cep }))

    if (cep.length === 8) {
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`)
        const data = await response.json()

        if (!data.erro) {
          const newAddressData = {
            ...addressData,
            cep,
            endereco: data.logradouro || "",
            bairro: data.bairro || "",
            cidade: data.localidade || "",
            estado: data.uf || "",
          }
          setAddressData(newAddressData)

          const shipping = calculateShipping(data.localidade, data.uf)
          setShippingCost(shipping)
          setIsValidAddress(shipping >= 0)
        }
      } catch (error) {
        console.error("Erro ao buscar CEP:", error)
      }
    }
  }

  const handleAddToCart = () => {
    if (!selectedSize) {
      alert("Por favor, selecione um tamanho")
      return
    }

    if (showColorSelector && !selectedColor) {
      alert("Por favor, selecione uma cor")
      return
    }

    addItem({
      id: product.id,
      name: product.name,
      brand: product.brand,
      price: product.price,
      image: product.images[0],
      size: selectedSize,
      color: selectedColor,
      quantity: quantity,
      sku: product.sku,
    })

    openCart()
  }

  const handleBuyNow = () => {
    if (!selectedSize) {
      alert("Por favor, selecione um tamanho")
      return
    }

    if (showColorSelector && !selectedColor) {
      alert("Por favor, selecione uma cor")
      return
    }

    setShowAddressModal(true)
  }

  const handleFinalizePurchase = () => {
    if (!isValidAddress) {
      alert("Por favor, preencha um endereço válido em Goiás")
      return
    }

    if (!addressData.numero) {
      alert("Por favor, preencha o número do endereço")
      return
    }

    const colorText = selectedColor ? ` - Cor: ${selectedColor}` : ""
    const shippingText = shippingCost === 0 ? "FRETE GRÁTIS" : `Frete: R$ ${shippingCost.toFixed(2).replace(".", ",")}`
    const productTotal = Number.parseFloat(product.price.replace("R$ ", "").replace(",", ".")) * quantity
    const total = productTotal + shippingCost

    const message = `🛍️ *PEDIDO SANTURE GRIFES*

📦 *Produto:* ${product.name}
👕 *Tamanho:* ${selectedSize}${colorText}
📊 *Quantidade:* ${quantity}
💰 *Valor:* ${product.price} x ${quantity} = R$ ${productTotal.toFixed(2).replace(".", ",")}

📍 *Endereço de Entrega:*
${addressData.endereco}, ${addressData.numero}
${addressData.bairro} - ${addressData.cidade}/${addressData.estado}
CEP: ${addressData.cep}

🚚 *Frete:* ${shippingText}
💳 *TOTAL:* R$ ${total.toFixed(2).replace(".", ",")}

Gostaria de finalizar este pedido!`

    const whatsappUrl = `https://wa.me/5562995432028?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
    setShowAddressModal(false)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Product Images */}
        <div className="space-y-4">
          {/* Main Image */}
          <div className="aspect-square overflow-hidden rounded-lg bg-gray-100">
            <img
              src={product.images[selectedImage] || "/placeholder.svg"}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Thumbnail Images */}
          <div className="grid grid-cols-4 gap-4">
            {product.images.map((image, index) => (
              <button
                key={index}
                onClick={() => setSelectedImage(index)}
                className={`aspect-square overflow-hidden rounded-lg border-2 transition-colors ${
                  selectedImage === index ? "border-amber-600" : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <img
                  src={image || "/placeholder.svg"}
                  alt={`${product.name} ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          {/* Brand and Name */}
          <div>
            <Badge variant="secondary" className="mb-2 bg-amber-100 text-amber-800">
              {product.brand}
            </Badge>
            <h1 className="font-serif font-bold text-3xl text-slate-700">{product.name}</h1>
            <p className="text-sm text-slate-500 mt-1">SKU: {product.sku}</p>
          </div>

          {/* Price */}
          <div className="flex items-center gap-4">
            <span className="text-3xl font-bold text-slate-700">{product.price}</span>
          </div>

          {/* Description */}
          <div>
            <h3 className="font-semibold text-lg mb-2">Descrição</h3>
            <p className="text-slate-600 leading-relaxed">{product.description}</p>
          </div>

          {/* Features */}
          <div>
            <h3 className="font-semibold text-lg mb-3">Características</h3>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {product.features.map((feature, index) => (
                <li key={index} className="flex items-center text-sm text-slate-600">
                  <div className="w-2 h-2 bg-amber-600 rounded-full mr-3 flex-shrink-0"></div>
                  {feature}
                </li>
              ))}
            </ul>
          </div>

          {/* Color Selection */}
          {showColorSelector && (
            <div>
              <h3 className="font-semibold text-lg mb-3">Cor</h3>
              <div className="flex gap-3">
                {availableColors.map((color) => (
                  <button
                    key={color.value}
                    onClick={() => setSelectedColor(color.name)}
                    className={`flex flex-col items-center gap-2 p-3 border rounded-lg transition-colors ${
                      selectedColor === color.name
                        ? "border-amber-600 bg-amber-50"
                        : "border-gray-300 hover:border-gray-400"
                    }`}
                  >
                    <div
                      className="w-8 h-8 rounded-full border-2"
                      style={{
                        backgroundColor: color.color,
                        borderColor: color.border,
                      }}
                    />
                    <span className="text-sm font-medium">{color.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Size Selection */}
          <div>
            <h3 className="font-semibold text-lg mb-3">Tamanho</h3>
            <div className="flex gap-2">
              {product.sizes.map((size) => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`px-4 py-2 border rounded-lg font-medium transition-colors ${
                    selectedSize === size
                      ? "border-amber-600 bg-amber-50 text-amber-800"
                      : "border-gray-300 hover:border-gray-400"
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Quantity */}
          <div>
            <h3 className="font-semibold text-lg mb-3">Quantidade</h3>
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
              >
                <Minus className="h-4 w-4" />
              </Button>
              <span className="text-lg font-medium w-12 text-center">{quantity}</span>
              <Button variant="outline" size="icon" onClick={() => setQuantity(quantity + 1)} disabled={quantity >= 10}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <Button onClick={handleBuyNow} size="lg" className="w-full bg-amber-600 hover:bg-amber-700 text-white">
              Comprar Agora
            </Button>
            <Button
              onClick={handleAddToCart}
              variant="outline"
              size="lg"
              className="w-full border-slate-300 text-slate-700 hover:bg-slate-50 bg-transparent"
            >
              Adicionar ao Carrinho
            </Button>
            <div className="flex gap-2">
              <Button variant="ghost" size="icon" className="flex-1">
                <Heart className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="flex-1">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Trust Indicators */}
          <Card className="p-4">
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm text-slate-600">
                <Truck className="h-5 w-5 text-green-600" />
                <span>Frete grátis para Goiânia e região</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-slate-600">
                <Shield className="h-5 w-5 text-blue-600" />
                <span>Autenticidade 100% garantida</span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <Dialog open={showAddressModal} onOpenChange={setShowAddressModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-serif text-slate-700">Dados para Entrega</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="cep">CEP</Label>
              <Input
                id="cep"
                placeholder="00000-000"
                value={addressData.cep}
                onChange={(e) => handleCepChange(e.target.value.replace(/\D/g, ""))}
                maxLength={8}
              />
            </div>

            <div>
              <Label htmlFor="endereco">Endereço</Label>
              <Input
                id="endereco"
                value={addressData.endereco}
                onChange={(e) => setAddressData((prev) => ({ ...prev, endereco: e.target.value }))}
                placeholder="Rua, Avenida..."
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="numero">Número</Label>
                <Input
                  id="numero"
                  value={addressData.numero}
                  onChange={(e) => setAddressData((prev) => ({ ...prev, numero: e.target.value }))}
                  placeholder="123"
                />
              </div>
              <div>
                <Label htmlFor="bairro">Bairro</Label>
                <Input
                  id="bairro"
                  value={addressData.bairro}
                  onChange={(e) => setAddressData((prev) => ({ ...prev, bairro: e.target.value }))}
                  placeholder="Centro"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="cidade">Cidade</Label>
                <Input
                  id="cidade"
                  value={addressData.cidade}
                  onChange={(e) => setAddressData((prev) => ({ ...prev, cidade: e.target.value }))}
                  placeholder="Goiânia"
                />
              </div>
              <div>
                <Label htmlFor="estado">Estado</Label>
                <Input
                  id="estado"
                  value={addressData.estado}
                  onChange={(e) => setAddressData((prev) => ({ ...prev, estado: e.target.value }))}
                  placeholder="GO"
                />
              </div>
            </div>

            {shippingCost >= 0 && addressData.cidade && (
              <Card className="p-3 bg-green-50 border-green-200">
                <div className="flex items-center gap-2 text-green-700">
                  <Truck className="h-4 w-4" />
                  <span className="text-sm font-medium">
                    {shippingCost === 0 ? "Frete Grátis!" : `Frete: R$ ${shippingCost.toFixed(2).replace(".", ",")}`}
                  </span>
                </div>
              </Card>
            )}

            {shippingCost === -1 && addressData.estado && (
              <Card className="p-3 bg-red-50 border-red-200">
                <div className="flex items-center gap-2 text-red-700">
                  <MapPin className="h-4 w-4" />
                  <span className="text-sm font-medium">Entregamos apenas no estado de Goiás</span>
                </div>
              </Card>
            )}

            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={() => setShowAddressModal(false)} className="flex-1">
                Cancelar
              </Button>
              <Button
                onClick={handleFinalizePurchase}
                disabled={!isValidAddress || !addressData.numero}
                className="flex-1 bg-amber-600 hover:bg-amber-700"
              >
                Finalizar Pedido
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
